import React, { Component } from "react";
import "./App.css";
//this Model is the class,calling calss Model from Model.js
import Model from "./Components/Model/Model";
import Works from "./Components/Works/Works";

class App extends Component {
  //by default, show:false
  state = {
    show: false,

    projects: [
      {
        id: "one",
        name: "Project One",
        description: "First Project blahblahblah"
      },
      {
        id: "two",
        name: "Project Two",
        description: "Second Project blahblahblah"
      },
      {
        id: "three",
        name: "Project Three",
        description: "Third Project blahblahblah"
      },
      {
        id: "four",
        name: "Project Four",
        description: "Fourth Project blahblahblah"
      }
    ]
  };

  showModel = () => {
    this.setState({
      // show:true

      //如果show本来是false,那么这里的show变成true,如果show本来是true,这里的show变成false
      show: !this.state.show
    });
  };

  render() {
    //declare for loop, render it first then return
    const items = this.state.projects.map(data => (
      //map all the data in this format
      <div className="Gallery">
        <h2>{data.name}</h2>
        <p>{data.description}</p>
      </div>
    ));

    return (
      //cannot do a lots of div, only one big div
      <div className="App">
        <h1>Hello! I am Kennis.</h1>
        <p>I am NY based designer who enjoys making stuffs.</p>

        {/* <h2>{this.state.projects[0].name}</h2> */}

        <button
          onClick={() => {
            this.showModel();
          }}
        >
          ABOUT ME
        </button>

        <button
          onClick={() => {
            this.showWorks();
          }}
        >
          WORK
        </button>

        {items}

        <Model onClose={this.showModel} show={this.state.show}>
          This is my resume!!!
        </Model>

        <Works onClose={this.showWorks} show={this.state.show}>
          These are my projects!!
        </Works>
      </div>
    );
  }
}

export default App;
