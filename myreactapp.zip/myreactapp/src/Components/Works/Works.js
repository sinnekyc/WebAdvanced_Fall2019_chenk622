import React, { Component } from "react";
import "./Works.css";
import { directive } from "@babel/types";

//class不等于class name
class Works extends Component {
  onClose = () => {
    this.props.onClose();
  };

  render() {
    //props=properties
    //if the properties is not props in the 'show'
    //the default show property is false， 所以return null
    if (!this.props.show) {
      return null;
    }

    //当trigger,show Model这个class
    return (
      <div className="myWorks">
        <div className="container">
          <h1>{this.props.children}</h1>
          <div>
            <span
              id="close"
              onClick={() => {
                this.onClose();
              }}
            >
              &#10005;
            </span>
          </div>
        </div>
      </div>
    );
  }
}

export default Works;
