export const projects = [
    {
      name: 'Awesome Project',
      description: 'This is the best you\'ve seen!!'

    },
    {
      name: 'Great Project',
      description: 'A great project ... hire me!!'
    },
    {
      name: 'Super Cool Project',
      description: 'What else do you wanna know?!!'
    }

  ];